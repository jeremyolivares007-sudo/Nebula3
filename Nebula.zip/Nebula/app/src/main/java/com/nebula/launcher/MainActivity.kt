package com.nebula.launcher

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import org.json.JSONArray
import org.json.JSONObject
import android.app.AlertDialog
import android.text.InputType
import android.widget.EditText

class MainActivity : Activity() {

    private companion object {
        const val MC_PACKAGE = "com.mojang.minecraftpe"
        const val REQ_PICK = 1001
        val ALLOWED_EXT = listOf("mcpack", "mcaddon", "mcworld", "mctemplate")

        val BG = Color.parseColor("#0B0F1A")
        val CARD = Color.parseColor("#141A2B")
        val ACCENT = Color.parseColor("#5CE1FF")
        val ACCENT_2 = Color.parseColor("#7C5CFF")
        val TEXT = Color.parseColor("#E8ECF8")
        val MUTED = Color.parseColor("#8A94B2")
        val OK = Color.parseColor("#4ADE80")
        val BAD = Color.parseColor("#F87171")
    }

    private lateinit var status: TextView
    private lateinit var serverList: LinearLayout
    private val prefs by lazy { getSharedPreferences("nebula", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ------------------------------------------------------------------ UI
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 16) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(32))
        }

        root.addView(TextView(this).apply {
            text = "NEBULA"
            setTextColor(ACCENT)
            textSize = 40f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            letterSpacing = 0.25f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Tu cliente para Minecraft Bedrock"
            setTextColor(MUTED)
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(28))
        })

        status = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            background = rounded(CARD)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        root.addView(status, lp(bottom = 20))

        root.addView(primaryButton("Abrir Minecraft") { openMinecraft() }, lp(bottom = 12))
        root.addView(secondaryButton("Importar pack o mundo") { pickFile() }, lp(bottom = 24))

        root.addView(TextView(this).apply {
            text = "SERVIDORES"
            setTextColor(ACCENT)
            textSize = 13f
            letterSpacing = 0.2f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(4), 0, 0, dp(8))
        })
        serverList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(serverList, lp(bottom = 4))
        root.addView(secondaryButton("+ Agregar servidor") { addServerDialog() }, lp(bottom = 8))
        root.addView(TextView(this).apply {
            text = "Toca un servidor para entrar. Manten pulsado para borrarlo."
            setTextColor(MUTED)
            textSize = 12f
            setPadding(dp(4), 0, 0, 0)
        })
        renderServers()

        return ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
            addView(root)
        }
    }

    private fun lp(bottom: Int = 0) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(bottom) }

    private fun primaryButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(BG)
        typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(ACCENT, ACCENT_2)
        ).apply { cornerRadius = dp(16).toFloat() }
        setPadding(dp(16), dp(18), dp(16), dp(18))
        setOnClickListener { onClick() }
    }

    private fun secondaryButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setTextColor(TEXT)
        background = rounded(CARD)
        setPadding(dp(16), dp(18), dp(16), dp(18))
        setOnClickListener { onClick() }
    }

    private fun refreshStatus() {
        if (isMinecraftInstalled()) {
            status.text = "Minecraft Bedrock detectado"
            status.setTextColor(OK)
        } else {
            status.text = "Minecraft Bedrock no esta instalado"
            status.setTextColor(BAD)
        }
    }

    // ------------------------------------------------------------------ Acciones
    private fun isMinecraftInstalled(): Boolean = try {
        packageManager.getPackageInfo(MC_PACKAGE, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun openMinecraft() {
        val intent = packageManager.getLaunchIntentForPackage(MC_PACKAGE)
        if (intent == null) toast("Instala Minecraft Bedrock primero.") else startActivity(intent)
    }

    private fun shareDir(): File = File(cacheDir, "share").apply { mkdirs() }

    private fun pickFile() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(Intent.createChooser(intent, "Elige un pack o mundo"), REQ_PICK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val name = displayName(uri) ?: "archivo"
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext !in ALLOWED_EXT) {
            toast("Formato no valido. Usa: ${ALLOWED_EXT.joinToString { ".$it" }}")
            return
        }
        try {
            val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val out = File(shareDir(), safeName)
            contentResolver.openInputStream(uri)?.use { input ->
                out.outputStream().use { input.copyTo(it) }
            } ?: throw IllegalStateException("No se pudo leer el archivo")
            openInMinecraft(out)
        } catch (e: Exception) {
            toast("Error al importar: ${e.message}")
        }
    }

    private fun displayName(uri: Uri): String? =
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) c.getString(i) else null
        }

    // ------------------------------------------------------------------ Servidores
    private data class Server(val name: String, val host: String, val port: Int)

    private fun loadServers(): MutableList<Server> {
        val arr = JSONArray(prefs.getString("servers", "[]"))
        return MutableList(arr.length()) {
            val o = arr.getJSONObject(it)
            Server(o.getString("n"), o.getString("h"), o.getInt("p"))
        }
    }

    private fun saveServers(list: List<Server>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("n", it.name).put("h", it.host).put("p", it.port)) }
        prefs.edit().putString("servers", arr.toString()).apply()
    }

    private fun renderServers() {
        serverList.removeAllViews()
        val list = loadServers()
        if (list.isEmpty()) {
            serverList.addView(TextView(this).apply {
                text = "Aun no tienes servidores guardados."
                setTextColor(MUTED)
                textSize = 14f
                background = rounded(CARD)
                setPadding(dp(16), dp(14), dp(16), dp(14))
            }, lp(bottom = 8))
            return
        }
        list.forEach { sv ->
            val btn = secondaryButton("${sv.name}\n${sv.host}:${sv.port}") { joinServer(sv) }
            btn.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            btn.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setTitle("Borrar servidor")
                    .setMessage(sv.name)
                    .setPositiveButton("Borrar") { _, _ ->
                        saveServers(loadServers().filterNot { it == sv })
                        renderServers()
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
                true
            }
            serverList.addView(btn, lp(bottom = 8))
        }
    }

    private fun addServerDialog() {
        fun field(hint: String, type: Int, value: String = "") = EditText(this).apply {
            this.hint = hint
            inputType = type
            setText(value)
        }
        val name = field("Nombre", InputType.TYPE_CLASS_TEXT)
        val host = field("Direccion (ej. play.miservidor.com)", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        val port = field("Puerto", InputType.TYPE_CLASS_NUMBER, "19132")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(name); addView(host); addView(port)
        }
        AlertDialog.Builder(this)
            .setTitle("Agregar servidor")
            .setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val h = host.text.toString().trim()
                val p = port.text.toString().toIntOrNull()
                if (h.isEmpty() || p == null || p !in 1..65535) {
                    toast("Direccion o puerto no validos.")
                } else {
                    val n = name.text.toString().trim().ifEmpty { h }
                    saveServers(loadServers() + Server(n, h, p))
                    renderServers()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun joinServer(sv: Server) {
        if (!isMinecraftInstalled()) return toast("Instala Minecraft Bedrock primero.")
        val uri = Uri.parse("minecraft://connect/?serverUrl=${Uri.encode(sv.host)}&serverPort=${sv.port}")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(MC_PACKAGE))
        } catch (e: ActivityNotFoundException) {
            toast("Minecraft no pudo abrir el servidor.")
        }
    }

    private fun openInMinecraft(file: File) {
        if (!isMinecraftInstalled()) {
            toast("Instala Minecraft Bedrock primero.")
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/octet-stream")
            setPackage(MC_PACKAGE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            toast("Minecraft no pudo abrir el archivo.")
        }
    }
}
