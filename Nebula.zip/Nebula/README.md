# Nebula

Cliente Android para Minecraft Bedrock, sin trucos. No modifica el juego: usa el Minecraft oficial
instalado (el inicio de sesion con tu cuenta Xbox lo hace el propio juego).

## Funciones
- Pantalla de inicio propia y deteccion de Minecraft instalado.
- Lista de servidores guardada en la app, con entrada directa (toca para entrar, manten pulsado para borrar).
- Importar packs y mundos (.mcpack, .mcaddon, .mcworld, .mctemplate) directo al juego.

## Compilar el APK
Con Android Studio: abre esta carpeta, espera a Gradle y usa Build > Build APK(s).
Sin instalar nada: sube la carpeta (con `.github`) a un repositorio de GitHub, abre Actions > Build APK
y descarga el artefacto **Nebula-apk** (`app-debug.apk`).
